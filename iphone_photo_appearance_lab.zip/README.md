# iPhone向け 写真の見た目分析ラボ（静的版）

## この版の特徴
- `index.html` 1ファイルだけで動作します。
- iPhoneのSafariで利用可能。Node.jsやPythonサーバーは不要です。
- 画像処理はブラウザ内だけで実施し、写真をサーバーへ送信しません。
- 結果保存はそのiPhoneのブラウザ内（localStorage）のみです。
- 写真だけからカップ数を推定したり、架空のAI信頼度を表示したりしません。
- 画像品質の簡易チェックと、任意の実測値からの参考候補計算を含みます。

## iPhoneだけで公開する手順（GitHub + Netlify）
1. Safariで https://github.com を開き、無料アカウントを作成／ログイン。
2. GitHubで `+` → **New repository** を選び、名前を `photo-appearance-lab` などにして **Public** で作成。
3. リポジトリ画面で **Add file** → **Create new file**。ファイル名を `index.html` と入力。
4. このZIP内の `index.html` をiPhoneの「ファイル」アプリから開いてソースをすべてコピーし、GitHubの編集欄へ貼り付ける。長文の貼り付けが難しければ、PCを借りるか、GitHubへファイルをアップロードできる開発サービスを利用してください。
5. **Commit changes** を押して保存。
6. Safariで https://app.netlify.com を開き、GitHubアカウントで登録／ログイン。
7. **Add new site** / **Import an existing project** を選び、GitHubを接続して `photo-appearance-lab` を選択。
8. Build command は空欄、Publish directory は `.`（ドット）にしてDeploy。画面上で設定項目が異なる場合はNetlifyの案内に従ってください。
9. 公開された `https://....netlify.app` のURLをiPhone Safariで開く。
10. ホーム画面に追加：Safariの共有ボタン → **ホーム画面に追加**。

## 注意
- サイトをPublicにすると `index.html` のコードは公開されますが、写真や保存結果はコードに含まれません。
- 保存データは同じ端末・同じブラウザだけに残り、同期されません。
- サイズ候補は実測値の差分からの参考値であり、ブランド別フィットを保証しません。
- 公開前に自分の端末でテストしてください。iOSのバージョンによりボタン名や画面配置が変わる場合があります。
